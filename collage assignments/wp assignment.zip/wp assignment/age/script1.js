const name = document.getElementById('name')
const password = document.getElementById('password')
const form = document.getElementById('form')
const errorElement = document.getElementById('validation')

form.addEventListener('submit', (e) => {
  let messages = []
  
  if (name1.value === '' || name1.value == null ) {
    messages.push('Name is required')
  }

  if (password.value.length <= 6) {
    messages.push('Password must be longer than 6 characters')
  }

  if (password.value.length >= 10) {
    messages.push('Password must be less than 20 characters')
  }

  if (password.value === 'password') {
    messages.push('Password cannot be password')
  }

  if(Enrolment.value.length <=12)
  {
    messages.push('please valid enrrolment')
  }

  if (messages.length > 0) {
    e.preventDefault()
    errorElement.innerText = messages.join(', ')
  }
})
















function fnCalculateAge(){

  var userDateinput = document.getElementById("txtDOB").value;  
  console.log(userDateinput);
  
  // convert user input value into date object
  var birthDate = new Date(userDateinput);
   console.log(" birthDate"+ birthDate);
  
  // get difference from current date;
  var difference=Date.now() - birthDate.getTime(); 
       
  var  ageDate = new Date(difference); 
  var calculatedAge=   Math.abs(ageDate.getUTCFullYear() - 1970);
  alert(calculatedAge);
  messages.push("age"+ calculatedAge);
  }
  